package Controller;

import Model.*;
import View.*;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.SQLException;

public class viewController extends JFrame {

    public Connection databaseConnection;

    public viewController() {
        // Inisialisasi koneksi database
        try {
            databaseConnection = connector.bukaKoneksiDB();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Gagal terhubung ke database!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void closeDatabaseConnection() {
        connector.tutupKoneksiDB();
    }

    // Metode untuk menutup koneksi database saat frame dihapus
//    @Override
//    public void setDefaultCloseOperation(int operation) {
//        connector.tutupKoneksiDB();
//    }
    private viewController getFrame(String viewName) {
        return switch (viewName) {
            case "tampilanMenu" ->
                new tampilanMenu();
            case "tampilanBuatTiket" ->
                new tampilanBuatTiket();
            case "tampilanDaftarTiket" ->
                new tampilanDaftarTiket();
            case "tampilanPesanan" ->
                new tampilanPesanan();
            case "tampilanBeliTiket" ->
                new tampilanBeliTiket();
            default ->
                null;
        };
    }

    public <T extends viewController> void openFrame(T frame) {
        if (frame == null) {
            JOptionPane.showMessageDialog(this, "Frame tidak ditemukan!", "Error", JOptionPane.WARNING_MESSAGE);
        } else {
            frame.setLocationRelativeTo(this);
            frame.afterOpen();
            this.dispose();
            frame.setVisible(true);
        }
    }

    public void openFrame(String viewName) {
        viewController frame = getFrame(viewName);
        openFrame(frame);
    }

    public void afterOpen() {

    }
    
    public void urutanTabel(){
        
    }
}

