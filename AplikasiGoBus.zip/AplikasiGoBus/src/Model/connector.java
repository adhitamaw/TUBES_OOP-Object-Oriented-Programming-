    package Model;

    import java.sql.Connection;
    import java.sql.DriverManager;
    import java.sql.SQLException;

    public class connector {
        
        // Variabel untuk menyimpan koneksi ke database
        private static Connection konekdb;

        // Metode untuk membuka koneksi ke database
        public static Connection bukaKoneksiDB() throws SQLException {
            // Memeriksa apakah koneksi sudah dibuka sebelumnya
            if (konekdb == null) {
                // Informasi URL, username, dan password untuk koneksi ke database MySQL
                try {
                    String url = "jdbc:mysql://localhost:3307/aplikasikasirbus";
                    String user = "root";
                    String password = "";
                    
                    // Melakukan pemuatan driver dan membuat koneksi ke database
                    Class.forName("com.mysql.cj.jdbc.Driver");
                    konekdb = DriverManager.getConnection(url, user, password);
                } catch (ClassNotFoundException | SQLException ex) {
                    // Menangani exception jika terjadi kesalahan dalam pembukaan koneksi
                    throw new SQLException("Gagal membuka koneksi database", ex);
                }
            }
            return konekdb; // Mengembalikan koneksi ke pemanggil
        }

        // Metode untuk menutup koneksi ke database
        public static void tutupKoneksiDB() {
            try {
                // Menutup koneksi jika koneksi bukan null dan belum ditutup sebelumnya
                if (konekdb != null && !konekdb.isClosed()) {
                    konekdb.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace(); // Mencetak stack trace jika terjadi kesalahan saat menutup koneksi
            }
        }

    }
