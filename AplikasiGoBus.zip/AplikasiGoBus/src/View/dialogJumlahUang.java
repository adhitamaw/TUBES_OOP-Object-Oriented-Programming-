/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package View;

import Model.connector;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.PreparedStatement;


public class dialogJumlahUang extends javax.swing.JDialog {

    connector koneksi = new connector();

    tampilanBeliTiket parent;
    private String idPengguna;
    private String idTiket;
    private int jumlahTiket;

    public dialogJumlahUang(tampilanBeliTiket parent, boolean modal) {
        super(parent, modal);
        initComponents();
        this.parent = parent;

    }

    public void setInfoTransaksi(String idPengguna, String idTiket, int jumlahTiket) {
        this.idPengguna = idPengguna;
        this.idTiket = idTiket;
        this.jumlahTiket = jumlahTiket;
        hitungTotalHarga();
    }

    public void hitungTotalHarga() {
        try {
            String sql = "SELECT harga, tipeBus FROM tiket WHERE idTiket = ?";
            try (PreparedStatement preparedStatement = koneksi.bukaKoneksiDB().prepareStatement(sql)) {
                preparedStatement.setString(1, idTiket);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        int hargaTiket = resultSet.getInt("harga");
                        String tipeBus = resultSet.getString("tipeBus");

                        // Hitung total harga berdasarkan jumlah tiket dan harga tiket
                        int totalHarga = hargaTiket * jumlahTiket;

                        // Tambahkan pajak berdasarkan tipe bus
                        double pajak = 0.0;
                        if ("VIP".equals(tipeBus)) {
                            pajak = totalHarga * 0.10; // Pajak 10% untuk tipe bus VIP
                        } else {
                            pajak = totalHarga * 0.05; // Pajak 5% untuk tipe bus non VIP
                        }

                        // Hitung total harga setelah ditambah pajak
                        totalHarga += pajak;

                        inpHargaTotal.setText(String.valueOf(totalHarga));
                    } else {
                        // Handle jika idTiket tidak ditemukan
                        JOptionPane.showMessageDialog(this, "ID Tiket tidak ditemukan!", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exception
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        inpHargaTotal = new javax.swing.JTextField();
        inpJumlahUang = new javax.swing.JTextField();
        btnBayar = new javax.swing.JButton();
        btnKembali = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("MASUKKAN JUMLAH UANG");

        jLabel2.setText("Harga Total + Pajak");

        jLabel3.setText("Jumlah Uang");

        inpHargaTotal.setEditable(false);
        inpHargaTotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inpHargaTotalActionPerformed(evt);
            }
        });

        btnBayar.setText("BAYAR");
        btnBayar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBayarActionPerformed(evt);
            }
        });

        btnKembali.setText("KEMBALI");
        btnKembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnKembaliActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addComponent(jLabel1)
                .addContainerGap(74, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnKembali)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 120, Short.MAX_VALUE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(inpJumlahUang)
                            .addComponent(inpHargaTotal))
                        .addGap(46, 46, 46))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(61, 61, 61)
                        .addComponent(btnBayar)
                        .addContainerGap(90, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(inpHargaTotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel3)
                    .addComponent(inpJumlahUang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnBayar)
                    .addComponent(btnKembali))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnKembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKembaliActionPerformed
        this.dispose();
        parent.setVisible(true);
    }//GEN-LAST:event_btnKembaliActionPerformed

    private void btnBayarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBayarActionPerformed
        String inputJumlahUang = inpJumlahUang.getText();
        String inputTotalHarga = inpHargaTotal.getText();

        if (inputJumlahUang == null || inputJumlahUang.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Masukkan jumlah uang!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return; // Menghentikan eksekusi jika input jumlah uang kosong
        }

        if (inputTotalHarga == null || inputTotalHarga.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Total harga tidak valid!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return; // Menghentikan eksekusi jika total harga kosong atau tidak valid
        }

        // Konversi input ke tipe data numerik (misalnya int atau double)
        try {
            int jumlahUang = Integer.parseInt(inputJumlahUang);
            int totalHarga = Integer.parseInt(inputTotalHarga);

            if (jumlahUang < totalHarga) {
                JOptionPane.showMessageDialog(this, "Uang tidak mencukupi!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            } else {
                int kembalian = jumlahUang - totalHarga;
                JOptionPane.showMessageDialog(this, "Kembalian: " + kembalian, "Info", JOptionPane.INFORMATION_MESSAGE);

                // Lakukan proses pembayaran atau tindakan lainnya di sini
                String sql = "INSERT INTO daftarpesanan (idPengguna, idTiket, jumlahTiket, totalPembayaran) VALUES (?, ?, ?, ?)";
                try (PreparedStatement preparedStatement = koneksi.bukaKoneksiDB().prepareStatement(sql)) {
                    preparedStatement.setString(1, idPengguna);
                    preparedStatement.setString(2, idTiket);
                    preparedStatement.setInt(3, jumlahTiket);
                    preparedStatement.setInt(4, totalHarga);

                    // Eksekusi pernyataan SQL
                    preparedStatement.executeUpdate();
                    JOptionPane.showMessageDialog(this, "Tiket berhasil dibuat!", "Sukses", JOptionPane.INFORMATION_MESSAGE);

                    // Kembali ke tampilanMenu setelah membuat tiket
                    this.dispose();
                    parent.setVisible(true);

                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(this, "ID tiket tidak Ada" + e, "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Masukkan angka yang valid!", "Peringatan", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_btnBayarActionPerformed

    private void inpHargaTotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inpHargaTotalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_inpHargaTotalActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBayar;
    private javax.swing.JButton btnKembali;
    private javax.swing.JTextField inpHargaTotal;
    private javax.swing.JTextField inpJumlahUang;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    // End of variables declaration//GEN-END:variables
}
