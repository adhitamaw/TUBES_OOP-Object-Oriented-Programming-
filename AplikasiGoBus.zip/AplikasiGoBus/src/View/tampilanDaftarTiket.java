package View;

import Controller.*;
import Model.connector;
import javax.swing.table.DefaultTableModel;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.PreparedStatement;

public class tampilanDaftarTiket extends viewController {

    /**
     * Creates new form tampilanDaftarTiket
     */
    public tampilanDaftarTiket() {
        initComponents();
        afterOpen();
    }

    private void tampilkanTabel() {
        DefaultTableModel model = (DefaultTableModel) tblDaftarTiket.getModel();
        model.setRowCount(0); // Menghapus semua baris yang ada sebelum menambahkan yang baru

        try {
            String sql = "SELECT idTiket, tujuan, tipeBus, harga, kapasitasKursi FROM tiket";
            try (PreparedStatement preparedStatement = databaseConnection.prepareStatement(sql); ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    String idTiket = resultSet.getString("idTiket");
                    String tujuanBus = resultSet.getString("tujuan");
                    String jenisBus = resultSet.getString("tipeBus");
                    int hargaTiket = resultSet.getInt("harga");
                    int kapasitasKursi = resultSet.getInt("kapasitasKursi");

                    model.addRow(new Object[]{idTiket, tujuanBus, hargaTiket, kapasitasKursi, jenisBus});
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void afterOpen() {
        tampilkanTabel();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnKembali = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblDaftarTiket = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        cmbUrutanPencarian = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        btnKembali.setText("KEMBALI");
        btnKembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnKembaliActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("DAFTAR TIKET BUS");

        tblDaftarTiket.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id Tiket", "Tujuan", "Harga", "Kapasitas Kursi", "Tipe Bus"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tblDaftarTiket);
        if (tblDaftarTiket.getColumnModel().getColumnCount() > 0) {
            tblDaftarTiket.getColumnModel().getColumn(0).setResizable(false);
            tblDaftarTiket.getColumnModel().getColumn(1).setResizable(false);
            tblDaftarTiket.getColumnModel().getColumn(2).setResizable(false);
            tblDaftarTiket.getColumnModel().getColumn(3).setResizable(false);
            tblDaftarTiket.getColumnModel().getColumn(4).setResizable(false);
        }

        jLabel2.setText("Pencarian Berdasarkan :");

        cmbUrutanPencarian.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Default", "Harga Terendah", "Harga Tertinggi", "VIP", "Non VIP", " " }));
        cmbUrutanPencarian.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbUrutanPencarianActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cmbUrutanPencarian, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 479, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btnKembali)
                        .addGap(220, 220, 220))))
            .addGroup(layout.createSequentialGroup()
                .addGap(153, 153, 153)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel1)
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(cmbUrutanPencarian, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnKembali)
                .addGap(20, 20, 20))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnKembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKembaliActionPerformed
        openFrame("tampilanMenu");
    }//GEN-LAST:event_btnKembaliActionPerformed

    private void cmbUrutanPencarianActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbUrutanPencarianActionPerformed
        urutanTabel();
    }//GEN-LAST:event_cmbUrutanPencarianActionPerformed

    public void urutanTabel(){
        int urutan = cmbUrutanPencarian.getSelectedIndex();

        switch (urutan) {
            case 0:
                tampilkanTabel();
                break;
            case 1:
                DefaultTableModel modelLowestPrice = (DefaultTableModel) tblDaftarTiket.getModel();
                modelLowestPrice.setRowCount(0); // Menghapus semua baris yang ada sebelum menambahkan yang baru

                try {
                    String sql = "SELECT idTiket, tujuan, tipeBus, harga, kapasitasKursi FROM tiket ORDER BY harga ASC";
                    try (PreparedStatement preparedStatement = databaseConnection.prepareStatement(sql); ResultSet resultSet = preparedStatement.executeQuery()) {
                        while (resultSet.next()) {
                            String idTiket = resultSet.getString("idTiket");
                            String tujuanBus = resultSet.getString("tujuan");
                            String jenisBus = resultSet.getString("tipeBus");
                            int hargaTiket = resultSet.getInt("harga");
                            int kapasitasKursi = resultSet.getInt("kapasitasKursi");

                            modelLowestPrice.addRow(new Object[]{idTiket, tujuanBus, hargaTiket, kapasitasKursi, jenisBus});
                        }
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                break;
            case 2:
                DefaultTableModel modelHighestPrice = (DefaultTableModel) tblDaftarTiket.getModel();
                modelHighestPrice.setRowCount(0); // Menghapus semua baris yang ada sebelum menambahkan yang baru

                try {
                    String sql = "SELECT idTiket, tujuan, tipeBus, harga, kapasitasKursi FROM tiket ORDER BY harga DESC";
                    try (PreparedStatement preparedStatement = databaseConnection.prepareStatement(sql); ResultSet resultSet = preparedStatement.executeQuery()) {
                        while (resultSet.next()) {
                            String idTiket = resultSet.getString("idTiket");
                            String tujuanBus = resultSet.getString("tujuan");
                            String jenisBus = resultSet.getString("tipeBus");
                            int hargaTiket = resultSet.getInt("harga");
                            int kapasitasKursi = resultSet.getInt("kapasitasKursi");

                            modelHighestPrice.addRow(new Object[]{idTiket, tujuanBus, hargaTiket, kapasitasKursi, jenisBus});
                        }
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                break;
            case 3:
                DefaultTableModel modelVip = (DefaultTableModel) tblDaftarTiket.getModel();
                modelVip.setRowCount(0);

                try {
                    String sql = "SELECT idTiket, tujuan, tipeBus, harga, kapasitasKursi FROM tiket ORDER BY tipeBus ASC";
                    try (PreparedStatement preparedStatement = databaseConnection.prepareStatement(sql); ResultSet resultSet = preparedStatement.executeQuery()) {
                        while (resultSet.next()) {
                            String idTiket = resultSet.getString("idTiket");
                            String tujuanBus = resultSet.getString("tujuan");
                            String jenisBus = resultSet.getString("tipeBus");
                            int hargaTiket = resultSet.getInt("harga");
                            int kapasitasKursi = resultSet.getInt("kapasitasKursi");

                            modelVip.addRow(new Object[]{idTiket, tujuanBus, hargaTiket, kapasitasKursi, jenisBus});
                        }
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                break;
            case 4:
                DefaultTableModel modelNonVip = (DefaultTableModel) tblDaftarTiket.getModel();
                modelNonVip.setRowCount(0);

                try {
                    String sql = "SELECT idTiket, tujuan, tipeBus, harga, kapasitasKursi FROM tiket ORDER BY tipeBus DESC";
                    try (PreparedStatement preparedStatement = databaseConnection.prepareStatement(sql); ResultSet resultSet = preparedStatement.executeQuery()) {
                        while (resultSet.next()) {
                            String idTiket = resultSet.getString("idTiket");
                            String tujuanBus = resultSet.getString("tujuan");
                            String jenisBus = resultSet.getString("tipeBus");
                            int hargaTiket = resultSet.getInt("harga");
                            int kapasitasKursi = resultSet.getInt("kapasitasKursi");

                            modelNonVip.addRow(new Object[]{idTiket, tujuanBus, hargaTiket, kapasitasKursi, jenisBus});
                        }
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                break;
            default:
                tampilkanTabel();
                break;
        }
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnKembali;
    private javax.swing.JComboBox<String> cmbUrutanPencarian;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblDaftarTiket;
    // End of variables declaration//GEN-END:variables

}
